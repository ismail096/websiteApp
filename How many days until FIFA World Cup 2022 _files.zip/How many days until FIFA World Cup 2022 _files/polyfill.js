/* Disable minification (remove `.min` from URL path) for more info */

(function(undefined) {}).call('object' === typeof window && window || 'object' === typeof self && self || 'object' === typeof global && global || {});